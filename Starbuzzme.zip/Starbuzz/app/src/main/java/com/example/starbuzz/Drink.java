package com.example.starbuzz;

public class Drink {
    private String name;
    private String description;
    private int imageResourceId;

    public static final Drink []drinks ={
            new Drink("Bod", "Corte de pelo recto que generalmente llega hasta la mandíbula",
                    R.drawable.bob),
            new Drink("Pixie", "Estilo muy corto que resalta la forma del rostro.",
                    R.drawable.pixie),
            new Drink("Shag", " Corte desenfadado a base de capas degradadas que da un aspecto más texturizado y moderno.",
                    R.drawable.shag),


    };
         private Drink(String name, String description, int imageResourceId){
             this.name = name;
             this.description = description;
             this.imageResourceId = imageResourceId;
         }

    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }
    public String toString(){
             return this.name;
    }
}
